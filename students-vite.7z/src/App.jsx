import React, { useState, useEffect, useRef } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import * as XLSX from "xlsx";

import { classNames } from "primereact/utils";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

import { Toast } from "primereact/toast";
import { Button } from "primereact/button";
import { FileUpload } from "primereact/fileupload";
import { Rating } from "primereact/rating";
import { Toolbar } from "primereact/toolbar";
import { InputTextarea } from "primereact/inputtextarea";
import { RadioButton } from "primereact/radiobutton";
import { InputNumber } from "primereact/inputnumber";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { Tag } from "primereact/tag";
import "./App.css";
function App() {
  const emptyStudent = {
    RollNo: "",
    Name: "",
    Class: null,
    Gender: "Male",
    DOB: "",
    Pincode: null,
    Maths: null,
    Science: null,
    English: null,
    Geography: null,
  };

  const [students, setStudents] = useState([
    {
      RollNo: "10",
      Name: "Lakshmi",
      Class: 8,
      Gender: "Female",
      DOB: "10-15-2014",
      Pincode: "5673",
      Maths: 65,
      Science: 67,
      English: 24,
      Geography: 89,
    },
    {
      RollNo: "11",
      Name: "Ayush",
      Class: 9,
      Gender: "Male",
      DOB: "10-31-2017",
      Pincode: "9870",
      Maths: 72,
      Science: 78,
      English: 61,
      Geography: 90,
    },
  ]);

  const [studentDialog, setStudentDialog] = useState(false);
  const [deleteStudentDialog, setDeleteStudentDialog] = useState(false);
  const [deleteStudentsDialog, setDeleteStudentsDialog] = useState(false);
  const [student, setStudent] = useState(emptyStudent);
  const [selectedStudents, setSelectedStudents] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [globalFilter, setGlobalFilter] = useState(null);
  const toast = useRef(null);
  const dt = useRef(null);

  const handleFileUpload = (event) => {
    const file = event.files[0];

    if (file) {
      const reader = new FileReader();
      reader.readAsBinaryString(file);
      reader.onload = (e) => {
        const data = e.target.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

        // Assuming the first row in the imported data is the header
        const [header, ...dataRows] = parsedData;

        // Map each data row to a student object
        const importedStudents = dataRows.map((rowData) => {
          const newStudent = {};
          header.forEach((field, index) => {
            newStudent[field] = rowData[index];
          });
          return newStudent;
        });

        // Combine existing students with imported data
        setStudents([...students, ...importedStudents]);
      };
    }
  };

  const openNew = () => {
    setStudent(emptyStudent);
    setSubmitted(false);
    setStudentDialog(true);
  };

  const hideDialog = () => {
    setSubmitted(false);
    setStudentDialog(false);
  };

  const hideDeleteStudentDialog = () => {
    setDeleteStudentDialog(false);
  };

  const hideDeleteStudentsDialog = () => {
    setDeleteStudentsDialog(false);
  };

  const saveStudent = () => {
    setSubmitted(true);

    if (student.Name.trim()) {
      let _students = [...students];
      let _student = { ...student };

      if (student.RollNo) {
        const index = findIndexById(student.RollNo);

        _students[index] = _student;
        toast.current.show({
          severity: "success",
          summary: "Successful",
          detail: "Student Updated",
          life: 3000,
        });
      } else {
        _student.RollNo = createId();
        _student.image = "student-placeholder.svg";
        _students.push(_student);
        toast.current.show({
          severity: "success",
          summary: "Successful",
          detail: "Student Created",
          life: 3000,
        });
      }

      setStudents(_students);
      setStudentDialog(false);
      setStudent(emptyStudent);
    }
  };

  const editStudent = (student) => {
    setStudent({ ...student });
    setStudentDialog(true);
  };

  const confirmDeleteStudent = (student) => {
    setStudent(student);
    setDeleteStudentDialog(true);
  };

  const deleteStudent = () => {
    let _students = students.filter((val) => val.RollNo !== student.RollNo);

    setStudents(_students);
    setDeleteStudentDialog(false);
    setStudent(emptyStudent);
    toast.current.show({
      severity: "success",
      summary: "Successful",
      detail: "Student Deleted",
      life: 3000,
    });
  };

  const findIndexById = (RollNo) => {
    let index = -1;

    for (let i = 0; i < students.length; i++) {
      if (students[i].RollNo === RollNo) {
        index = i;
        break;
      }
    }

    return index;
  };

  const createId = () => {
    let RollNo = "";
    let chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (let i = 0; i < 5; i++) {
      RollNo += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    return RollNo;
  };

  const exportCSV = () => {
    dt.current.exportCSV();
  };

  const confirmDeleteSelected = () => {
    setDeleteStudentsDialog(true);
  };

  const deleteSelectedStudents = () => {
    let _students = students.filter((val) => !selectedStudents.includes(val));

    setStudents(_students);
    setDeleteStudentsDialog(false);
    setSelectedStudents(null);
    toast.current.show({
      severity: "success",
      summary: "Successful",
      detail: "Students Deleted",
      life: 3000,
    });
  };

  const onCategoryChange = (e) => {
    let _student = { ...student };

    _student["Gender"] = e.value;
    setStudent(_student);
  };

  const onInputChange = (e, name) => {
    const val = (e.target && e.target.value) || "";
    let _student = { ...student };

    _student[`${name}`] = val;

    setStudent(_student);
  };

  const onInputNumberChange = (e, name) => {
    const val = e.value || 0;
    let _student = { ...student };

    _student[`${name}`] = val;

    setStudent(_student);
  };

  const leftToolbarTemplate = () => {
    return (
      <div className="flex flex-wrap gap-2">
        <Button
          label="New"
          icon="pi pi-plus"
          severity="success"
          onClick={openNew}
        />
        <Button
          label="Delete"
          icon="pi pi-trash"
          severity="danger"
          onClick={confirmDeleteSelected}
          disabled={!selectedStudents || !selectedStudents.length}
        />
      </div>
    );
  };

  const rightToolbarTemplate = () => {
    return (
      <Button
        label="Export"
        icon="pi pi-upload"
        className="p-button-help"
        onClick={exportCSV}
      />
    );
  };

  const editDeleteTemp = (rowData) => {
    return (
      <React.Fragment>
        <Button
          icon="pi pi-pencil"
          rounded
          outlined
          className="mr-2"
          onClick={() => editStudent(rowData)}
        />
        <Button
          icon="pi pi-trash"
          rounded
          outlined
          severity="danger"
          onClick={() => confirmDeleteStudent(rowData)}
        />
      </React.Fragment>
    );
  };

  const header = (
    <div className="flex flex-wrap gap-2 align-items-center justify-content-between">
      <h4 className="m-0">Report card</h4>
      <span className="p-input-icon-left">
        <i className="pi pi-search" />
        <InputText
          type="search"
          onInput={(e) => setGlobalFilter(e.target.value)}
          placeholder="Search..."
        />
      </span>
    </div>
  );
  const studentDialogFooter = (
    <React.Fragment>
      <Button label="Cancel" icon="pi pi-times" outlined onClick={hideDialog} />
      <Button label="Save" icon="pi pi-check" onClick={saveStudent} />
    </React.Fragment>
  );
  const deleteStudentDialogFooter = (
    <React.Fragment>
      <Button
        label="No"
        icon="pi pi-times"
        outlined
        onClick={hideDeleteStudentDialog}
      />
      <Button
        label="Yes"
        icon="pi pi-check"
        severity="danger"
        onClick={deleteStudent}
      />
    </React.Fragment>
  );
  const deleteStudentsDialogFooter = (
    <React.Fragment>
      <Button
        label="No"
        icon="pi pi-times"
        outlined
        onClick={hideDeleteStudentsDialog}
      />
      <Button
        label="Yes"
        icon="pi pi-check"
        severity="danger"
        onClick={deleteSelectedStudents}
      />
    </React.Fragment>
  );
  return (
    <div>
      <h2>Students Data</h2>

      <Toast ref={toast} />
      <FileUpload
        mode="basic"
        accept=".xlsx, .xls"
        onSelect={handleFileUpload}
        className="p-button-success"
        chooseLabel="Import from Excel"
      />

      <Toolbar
        className="mb-4"
        left={leftToolbarTemplate}
        right={rightToolbarTemplate}
      ></Toolbar>

      <DataTable
        value={students}
        ref={dt}
        selection={selectedStudents}
        onSelectionChange={(e) => setSelectedStudents(e.value)}
        className="p-datatable-custom"
        dataKey="RollNo"
        paginator
        rows={10}
        rowsPerPageOptions={[5, 10, 25]}
        paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
        currentPageReportTemplate="Showing {first} to {last} of {totalRecords} Students"
        globalFilter={globalFilter}
        header={header}
      >
        <Column selectionMode="multiple" exportable={false}></Column>

        <Column field="RollNo" header="RollNo" />
        <Column field="Name" header="Name" />
        <Column field="Class" header="Class" />
        <Column field="Gender" header="Gender" />
        <Column field="DOB" header="DOB" />
        <Column field="Pincode" header="Pincode" />
        <Column field="Maths" header="Maths" />
        <Column field="Science" header="Science" />
        <Column field="English" header="English" />
        <Column field="Geography" header="Geography" />
        <Column
          body={editDeleteTemp}
          style={{ minWidth: "6rem", textAlign: "center" }}
        />
      </DataTable>

      <Dialog
        visible={studentDialog}
        style={{ width: "32rem" }}
        breakpoints={{ "960px": "75vw", "641px": "90vw" }}
        header="Student Details"
        modal
        className="p-fluid"
        footer={studentDialogFooter}
        onHide={hideDialog}
      >
        <div className="field col">
          <label htmlFor="name" className="font-bold">
            Name
          </label>
          <InputText
            id="Name"
            value={student.Name}
            onChange={(e) => onInputChange(e, "Name")}
            required
            autoFocus
            className={classNames({ "p-invalid": submitted && !student.Name })}
          />
          {submitted && !student.Name && (
            <small className="p-error">Name is required.</small>
          )}
        </div>
        <div className="field col">
          <label htmlFor="RollNo" className="font-bold">
            RollNo
          </label>
          <InputNumber
            id="RollNo"
            value={student.RollNo}
            onValueChange={(e) => onInputNumberChange(e, "RollNo")}
          />
        </div>

        <div className="field col">
          <label className="mb-3 font-bold">Gender</label>
          <div className="formgrid grid">
            <div className="field-radiobutton col-6">
              <RadioButton
                inputId="Gender1"
                name="Gender"
                value="Female"
                onChange={onCategoryChange}
                checked={student.Gender === "Female"}
              />
              <label htmlFor="category1">Female</label>
            </div>
            <div className="field-radiobutton col-6">
              <RadioButton
                inputId="Gender2"
                name="Gender"
                value="Male"
                onChange={onCategoryChange}
                checked={student.Gender === "Male"}
              />
              <label htmlFor="category2">Male</label>
            </div>
          </div>
        </div>

        <div className="field col">
          <label htmlFor="Class" className="font-bold">
            Class
          </label>
          <InputNumber
            id="Class"
            value={student.Class}
            onValueChange={(e) => onInputNumberChange(e, "Class")}
          />
        </div>
        <div className="field col">
          <label htmlFor="Pincode" className="font-bold">
            Pincode
          </label>
          <InputNumber
            id="Pincode"
            value={student.Pincode}
            onValueChange={(e) => onInputNumberChange(e, "Pincode")}
          />
        </div>
        <div className="field col">
          <label htmlFor="DOB" className="font-bold">
            DOB
          </label>
          <InputTextarea
            id="DOB"
            value={student.DOB}
            onChange={(e) => onInputChange(e, "DOB")}
          />
        </div>
        <div className="formgrid grid">
          <div className="field col">
            <label htmlFor="Maths" className="font-bold">
              Maths
            </label>
            <InputNumber
              id="Maths"
              value={student.Maths}
              onValueChange={(e) => onInputNumberChange(e, "Maths")}
            />
          </div>
          <div className="field col">
            <label htmlFor="Science" className="font-bold">
              Science
            </label>
            <InputNumber
              id="Science"
              value={student.Science}
              onValueChange={(e) => onInputNumberChange(e, "Science")}
            />
          </div>
          <div className="field col">
            <label htmlFor="English" className="font-bold">
              English
            </label>
            <InputNumber
              id="English"
              value={student.English}
              onValueChange={(e) => onInputNumberChange(e, "English")}
            />
          </div>
          <div className="field col">
            <label htmlFor="Geography" className="font-bold">
              Geography
            </label>
            <InputNumber
              id="Geography"
              value={student.Geography}
              onValueChange={(e) => onInputNumberChange(e, "Geography")}
            />
          </div>
        </div>
      </Dialog>

      <Dialog
        visible={deleteStudentDialog}
        style={{ width: "32rem" }}
        breakpoints={{ "960px": "75vw", "641px": "90vw" }}
        header="Confirm"
        modal
        footer={deleteStudentDialogFooter}
        onHide={hideDeleteStudentDialog}
      >
        <div className="confirmation-content">
          <i
            className="pi pi-exclamation-triangle mr-3"
            style={{ fontSize: "2rem" }}
          />
          {student && (
            <span>
              Are you sure you want to delete <b>{student.Name}</b>?
            </span>
          )}
        </div>
      </Dialog>

      <Dialog
        visible={deleteStudentsDialog}
        style={{ width: "32rem" }}
        breakpoints={{ "960px": "75vw", "641px": "90vw" }}
        header="Confirm"
        modal
        footer={deleteStudentsDialogFooter}
        onHide={hideDeleteStudentsDialog}
      >
        <div className="confirmation-content">
          <i
            className="pi pi-exclamation-triangle mr-3"
            style={{ fontSize: "2rem" }}
          />
          {student && (
            <span>Are you sure you want to delete the selected students?</span>
          )}
        </div>
      </Dialog>
    </div>
  );
}

export default App;
